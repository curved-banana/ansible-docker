<?php 
	phpinfo(); 
?>
